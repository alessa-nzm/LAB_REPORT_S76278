// Questions Array
const questions = [
    {
        question: "What does HTML stand for?",
        options: ["Hyper Text Markup Language", "High Text Machine Language", "Hyperlinks Text Mark Language"],
        answer: 0
    },
    {
        question: "Which language is used for styling web pages?",
        options: ["HTML", "CSS", "JavaScript"],
        answer: 1
    },
    {
        question: "Which language makes a web page interactive?",
        options: ["CSS", "HTML", "JavaScript"],
        answer: 2
    }
];

let currentQuestionIndex = 0;
let score = 0;
let timeLeft = 10;
let timer;

// Shuffle Questions
function shuffleQuestions() {
    questions.sort(() => Math.random() - 0.5);
}

// Start Timer
function startTimer() {
    timeLeft = 10;
    document.getElementById("time").textContent = timeLeft;

    timer = setInterval(() => {
        timeLeft--;
        document.getElementById("time").textContent = timeLeft;

        if (timeLeft === 0) {
            clearInterval(timer);
            nextQuestion();
        }
    }, 1000);
}

// Display Question
function displayQuestion() {
    clearInterval(timer);
    startTimer();

    const currentQuestion = questions[currentQuestionIndex];
    document.getElementById("question").textContent = currentQuestion.question;

    const optionsDiv = document.getElementById("options");
    optionsDiv.innerHTML = "";

    currentQuestion.options.forEach((option, index) => {
        const btn = document.createElement("button");
        btn.textContent = option;
        btn.onclick = () => checkAnswer(index);
        optionsDiv.appendChild(btn);
    });

    document.getElementById("feedback").textContent = "";
}

// Check Answer
function checkAnswer(selectedIndex) {
    clearInterval(timer);
    const correctAnswer = questions[currentQuestionIndex].answer;

    if (selectedIndex === correctAnswer) {
        score++;
        document.getElementById("feedback").textContent = "Correct!";
        document.getElementById("feedback").style.color = "green";
    } else {
        document.getElementById("feedback").textContent = "Incorrect!";
        document.getElementById("feedback").style.color = "red";
    }

    document.getElementById("score").textContent = "Score: " + score;
}

// Next Question
function nextQuestion() {
    currentQuestionIndex++;

    if (currentQuestionIndex < questions.length) {
        displayQuestion();
    } else {
        document.getElementById("quiz-container").innerHTML =
            "<h2>Quiz Finished!</h2><p>Your Final Score: " + score + "</p>";
    }
}

// Start Quiz
function startQuiz() {
    shuffleQuestions();
    displayQuestion();
}

// Button Event
document.getElementById("next-btn").addEventListener("click", nextQuestion);

// Start quiz when page loads
startQuiz();
